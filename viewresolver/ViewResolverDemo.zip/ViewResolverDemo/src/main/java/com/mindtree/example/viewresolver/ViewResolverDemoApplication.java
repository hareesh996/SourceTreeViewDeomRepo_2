package com.mindtree.example.viewresolver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ViewResolverDemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(ViewResolverDemoApplication.class, args);
    }
}
